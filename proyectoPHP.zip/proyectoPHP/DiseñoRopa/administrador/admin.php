<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Administrador</title>
</head>
<body>
	<div class="barra">
		<p><h1>Administración</h1></p>
		<p><h2>Bienvenido al panel de administración.</h2></p>
	</div>
	<br>
	<br>
	<div class="cuadros">
		<div class="cuadro1">
			<button class="positionbutton1"><a href="clothes.php"><p class="txtbtn">Ropa</p></a></button>
		</div>
		<div class="cuadro2">
			<button class="positionbutton2"><a href="users.php"><p class="txtbtn">Usuarios</p></a></button>
		</div>
	</div>



</body>
</html>