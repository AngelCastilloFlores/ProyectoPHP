"use strict";
var jquery = require("jquery");
var blueimp = require("blueimp-file-upload");