<?php include_once 'comprueba-session.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Tu tienda de ropa online</title>
		<link rel="stylesheet" type="text/css" href="estilos/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, minimun-scale=1.0">﻿
</head>
<body>
	<div class="menu-responsive">
		<div class="headTit">Be Fashion Be You</div>
		<nav class="navResponsive">
			<ul>
				<li class="active"><a href="inicio.php">Inicio</a></li>
				<li><a href="tienda.php">Tienda</a></li>
				<li><a href="#">Servicios</a></li>
				<li><a href="contacto.php">Contáctanos</a></li>
			</ul>
			<ul class="account">
				<li><a href="" id="usuario"></a></li>
				<li id="acceder"><a href="login.php">Acceder</a></li>
				<li><a href="?destroy">Salir</a></li>
			</ul>
		</nav>
	</div>
	<nav class="navBarMenu">
		<h3 class="titulo">BFBY</h3>
		<ul>
			<li class="active"><a href="inicio.php">Inicio</a></li>
			<li><a href="tienda.php">Tienda</a></li>
			<li><a href="#">Servicios</a></li>
			<li><a href="contacto.php">Contáctanos</a></li>
		</ul>
		<ul class="account">
				<li><a href="" id="usuario"></a></li>
				<li id="acceder"><a href="login.php">Acceder</a></li>
				<li><a href="?destroy">Salir</a></li>
		</ul>
	</nav>

	<div class="contenedor">
		<div class="PanelHead">
			<h4>Premium Denim + Essentials. No Retail Markup.</h4>
				<p class="txtHead">We design + craft luxury-grade denim and essentials and refuse to work with department stores and retail middlemen, passing on the savings to you.</p>
		</div>

		<div class="PanelImagenes">
			<div class="women">
				<a href="tienda.php"><img src="https://d4zpg1jklewne.cloudfront.net/steak/groups/home-image-left/feb-womens/original.jpg?1517875558"></a>
			</div>
			<div class="men">
				<a href="tienda.php"><img src="https://d4zpg1jklewne.cloudfront.net/steak/groups/home-image-right/feb-mens/original.jpg?1517875615"></a>
			</div>
		</div>
		<!--RESPONSIVE NO HACER CASO -->
		<div class="imagenMobile">
			<div class="womenMobile">
					<div class="panelMujer">
						<a href="tienda.php">
							<p>Mujer</p>
						</a>
					</div>
					<a href="tienda.php"><img src="https://d4zpg1jklewne.cloudfront.net/steak/groups/home-image-left/feb-womens/original.jpg?1517875558" width="100%"></a>
			</div>
			<div class="menMobile">
				<div class="panelHombre">
					<a href="tienda.php">
						<p>Hombre</p>
					</a>
				</div>
					<a href="tienda.php"><img src="https://d4zpg1jklewne.cloudfront.net/steak/groups/home-image-right/feb-mens/original.jpg?1517875615" width="100%"></a>
			</div>
		</div>
		<!--END RESPONSIVE-->
		
		<div class="BlackPanel">
			<div class="flex-wrapper">
					<div class="panel1">
						<div class="texto1">
							<h3>NOS PREOCUPAMOS</h3>
							<p>Last year, DSTLD became the first-ever fashion brand to launch a Reg A+ financing campaign. We raised over $1.7M from more than 1,700 investors, concentrated our efforts on growth, and most notably - our lifetime revenue by 194% in just 12 months - and are back for a second round.</p>
							<button class="readMore">LEER <b>+</b></button>
						</div>
					</div>

					<div class="panel2">
						<div class="texto2">
							<h3>SOBRE ENVIOS</h3>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes</p>
							Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes</p>
							<img src="imagenes/send.png">
							<img src="imagenes/line.png" class="line">
							<img src="imagenes/smile.png" class="line">
						</div>
					</div>
			</div>
		</div>
		<!-- RESPONSIVE NO HACER CASO -->
				<div class="BlackPanelMobile">
					<div class="envios">
						<h3>SOBRE ENVIOS</h3>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes</p>
							<img src="imagenes/send.png">
							<img src="imagenes/line.png" class="line">
							<img src="imagenes/smile.png" class="line">
					</div>
					<hr class="linea">
						<div class="nosotros">
								<h3>NOS PREOCUPAMOS</h3>
								<p>Last year, DSTLD became the first-ever fashion brand to launch a Reg A+ financing campaign. We raised over $1.7M from more than 1,700 investors, concentrated our efforts on growth, and most notably - our lifetime revenue by 194% in just 12 months - and are back for a second round.</p>
								<button class="readMore"><a href="contacto.php">LEER <b>+</a></b></button>
						</div>
				</div>
		<div class="footer">
			<br>
			<div class="txtFooter">
				<h3>¡Recibe los mejores descuentos!</h3>
				<br>
					<form class="suscribe">
						<input type="text" class="email" maxlength="50" placeholder="Correo electrónico">
						<button type="button" class="btn btn-dark">Enviar</button>
					</form>
				<br>
				<p>Puedes darte de baja en cualquiér momento</p>
				<br>
			</div>
			<div class="pie">
				<br>
				<a href="#">| NOSOSTROS |</a>
				<a href="#">CONTACTO |</a>
				<a href="#">POLITICA DE PRIVACIDAD |</a>
				<a href="#">TERMINOS |</a>
			</div>
		</div>
	</div>
		<!-- END RESPONSIVE -->

</body>
</html>

